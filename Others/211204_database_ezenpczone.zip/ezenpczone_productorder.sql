-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ezenpczone
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `productorder`
--

DROP TABLE IF EXISTS `productorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productorder` (
  `po_no` int NOT NULL AUTO_INCREMENT,
  `po_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `po_contents` varchar(5000) NOT NULL,
  `po_count` int NOT NULL,
  `pc_no` int NOT NULL,
  `m_id` varchar(5000) NOT NULL,
  `po_price` int NOT NULL,
  `po_activation` int NOT NULL,
  PRIMARY KEY (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productorder`
--

LOCK TABLES `productorder` WRITE;
/*!40000 ALTER TABLE `productorder` DISABLE KEYS */;
INSERT INTO `productorder` VALUES (18,'2017-01-22 05:24:56','식품',10,1,'asdf',26500,1),(19,'2017-04-22 05:25:01','식품',1,1,'asdf',2000,1),(20,'2017-05-22 05:25:13','식품',14,1,'asdf',28800,1),(21,'2017-08-22 05:25:35','식품',11,1,'asdf',16500,1),(22,'2017-11-22 05:27:42','식품',7,1,'asdf',15000,1),(23,'2018-02-22 05:27:54','식품',14,1,'asdf',23200,1),(24,'2018-04-22 05:28:03','식품',11,1,'asdf',36500,1),(25,'2018-05-22 05:28:15','식품',21,1,'asdf',43000,1),(26,'2018-07-22 05:29:00','식품',16,1,'asdf',26800,1),(27,'2018-10-22 05:29:08','식품',2,1,'asdf',3000,1),(28,'2019-01-22 05:29:14','식품',2,1,'asdf',4000,1),(29,'2019-03-22 05:29:23','식품',4,1,'asdf',11500,1),(30,'2019-05-22 05:29:30','식품',7,1,'asdf',13500,1),(31,'2019-08-22 05:29:48','식품',10,1,'asdf',22300,1),(32,'2019-12-22 05:30:14','식품',5,1,'asdf',10000,1),(33,'2020-01-22 05:38:06','식품',6,1,'asdf',11000,1),(34,'2020-02-22 05:38:18','식품',11,1,'asdf',16500,1),(35,'2020-05-22 05:38:24','식품',4,1,'asdf',7500,1),(36,'2020-07-22 05:38:29','식품',4,1,'asdf',3200,1),(37,'2020-11-22 05:38:34','식품',4,1,'asdf',6000,1),(38,'2021-01-22 05:38:41','식품',3,1,'asdf',9000,1),(39,'2021-03-22 05:38:47','식품',6,1,'asdf',12500,1),(40,'2021-06-22 05:38:53','식품',2,1,'asdf',3500,1),(41,'2021-08-22 05:38:58','식품',3,1,'asdf',6500,1),(42,'2021-12-22 05:39:04','식품',3,1,'asdf',5000,1),(43,'2021-11-15 06:48:08','식품',4,10,'ezen1',10000,1),(44,'2021-11-16 06:48:13','식품',2,10,'ezen1',3000,1),(45,'2021-11-17 06:48:17','식품',2,10,'ezen1',4500,1),(46,'2021-11-18 06:48:21','식품',3,10,'ezen1',6000,1),(47,'2021-11-19 06:48:30','식품',1,10,'ezen1',3000,1),(48,'2021-12-03 14:55:49','식품',6,5,'ezen1',12000,1),(49,'2021-12-03 14:57:18','식품',3,5,'ezen1',5300,1),(50,'2021-12-04 08:39:55','식품',15,8,'ezen0',27500,1),(51,'2021-12-04 09:28:56','식품',19,7,'ezen15',53000,1),(52,'2021-12-04 10:35:22','식품',15,6,'ezen21',25400,2);
/*!40000 ALTER TABLE `productorder` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-04 19:54:07
